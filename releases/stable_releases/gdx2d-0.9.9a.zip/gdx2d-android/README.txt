*************
gdx2d-android
*************

This is a simple project for Android to run your application. To execute your code on Android, you only have to instantiate the correct class in GameActivity.java.
