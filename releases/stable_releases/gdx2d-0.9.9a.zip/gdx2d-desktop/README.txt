*************
gdx2d-desktop
*************

This project contains the library as well as all the demo programs. All the demos can be run on PC or on Android. In order to run a demo, either use the DemoSelector class which provides a simple way to choose which demo to run. You can also run each demo individually.