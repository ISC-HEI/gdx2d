package hevs.gdx2d.demos.physics.rocket;

import hevs.gdx2d.components.bitmaps.BitmapImage;
import hevs.gdx2d.lib.GdxGraphics;
import hevs.gdx2d.lib.interfaces.DrawableObject;

public class Sky implements DrawableObject{
	static BitmapImage image = new BitmapImage("data/images/rocket_128.png");
	
	Sky()
	{
		
	}
	
	@Override
	public void draw(GdxGraphics g) {
	
		
	}
}
