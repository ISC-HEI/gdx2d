package hevs.gdx2d.demos.physics.joints;

import hevs.gdx2d.components.physics.PhysicsBox;
import hevs.gdx2d.components.physics.PhysicsStaticBox;
import hevs.gdx2d.components.physics.utils.PhysicsConstants;
import hevs.gdx2d.components.physics.utils.PhysicsScreenBoundaries;
import hevs.gdx2d.lib.GdxGraphics;
import hevs.gdx2d.lib.PortableApplication;
import hevs.gdx2d.lib.physics.DebugRenderer;
import hevs.gdx2d.lib.physics.PhysicsWorld;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.EdgeShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.physics.box2d.joints.RevoluteJointDef;

public class DemoRopeJoint extends PortableApplication {

	// Contains all the objects that will be simulated
	World world = PhysicsWorld.getInstance();
	PhysicsBox box;
	DebugRenderer debugRenderer;

	public DemoRopeJoint(boolean onAndroid) {
		super(onAndroid);
	}

	@Override
	public void onInit() {

		Body ground = null;
		setTitle("Simple Rope Joint simulation, hit 2013");

		int w = getWindowWidth(), h = getWindowHeight();

		// Build the walls around the screen
		new PhysicsScreenBoundaries(w, h);

		debugRenderer = new DebugRenderer();

		// The amount of rope segments
		int N = 10;

		// The offset between each rope element
		float y = 225;

		// The box in the middle of the screen for the origin
		PhysicsStaticBox origin = new PhysicsStaticBox(null, new Vector2(
				Gdx.graphics.getWidth() / 2, Gdx.graphics.getHeight() / 2), 10,
				10);
		Body prevBody = origin.getBody();

		// The small piece of string
		PolygonShape shape1 = new PolygonShape();
		shape1.setAsBox(8*PhysicsConstants.METERS_TO_PIXELS, 2*PhysicsConstants.METERS_TO_PIXELS);

		FixtureDef fd = new FixtureDef();
		fd.shape = shape1;
		fd.density = 20.0f;
		fd.friction = 1.0f;
		fd.filter.categoryBits = 0x0001;
		fd.filter.maskBits = (short) 0xFFFF & ~0x0002;

		// The pin creator which is reused
		RevoluteJointDef jd = new RevoluteJointDef();
		jd.collideConnected = false;

		for (int i = 0; i < N; ++i) {
			BodyDef bd1 = new BodyDef();
			bd1.type = BodyType.DynamicBody;

			// Position of the rope segment
			bd1.position.set(250 + 15.0f * i, y);

//			// bd1.position.set( 120.0f * i, y );
//			if (i == N - 1) {
//				shape1.setAsBox(15, 15);
//				fd.density = 100.0f;
//				fd.filter.categoryBits = 0x0002;
//				bd1.position.set(250 + 15.0f * i, y);
//				bd1.angularDamping = 0.4f;
//			}
			Body body = world.createBody(bd1);
			body.createFixture(fd);

			// Creates the hinge between the rope segments
			Vector2 anchor = new Vector2(250 + i * 15, y);
			jd.initialize(prevBody, body, anchor);
			world.createJoint(jd);

			prevBody = body;
		}
	}

	@Override
	public void onGraphicRender(GdxGraphics g) {
		g.clear();

		debugRenderer.render(world, g.getCamera().combined);
		PhysicsWorld.updatePhysics();

		g.drawSchoolLogoUpperRight();
		g.drawFPS();
	}

	public static void main(String args[]) {
		new DemoRopeJoint(false);
	}
}
