package hevs.gdx2d.lib;

/**
 * Version of the library. 
 * @author Pierre-André Mudry
 * @version 1.0
 */
public class Version {
	public static final String version = "0.99a";
}
