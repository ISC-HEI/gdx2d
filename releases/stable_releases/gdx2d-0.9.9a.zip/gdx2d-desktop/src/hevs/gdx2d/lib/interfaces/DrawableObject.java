package hevs.gdx2d.lib.interfaces;

import hevs.gdx2d.lib.GdxGraphics;

public interface DrawableObject {
	void draw(GdxGraphics g);
}
