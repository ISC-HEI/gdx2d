package hevs.gdx2d.lib.perf_tests;

/**
 * TODO implement this
 * @author Pierre-André Mudry (mui)
 * @version 0
 */
public class Benchmarker {

	public static void main(String[] args) {

	}

}
